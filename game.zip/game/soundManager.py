
import pygame
import random

pygame.mixer.init()

class SoundManager():
    """Classe pour gérer le son et les bruitages
    ...Path: chemin de fichier mp3
    """
    def __init__(self):
        self.lostHealthPointPathList = ["SOUND/attention.mp3", "SOUND/nule.mp3", "SOUND/vie.mp3", "SOUND/t_NUL.mp3"]
        self.shootSoundPath = "SOUND/shoot.mp3"
        self.shieldSoundPath = "SOUND/shield.mp3"
        self.oussem = "SOUND/t_NUL.mp3"

    def playSound(self, soundPath):
        pygame.mixer.music.load(soundPath)
        pygame.mixer.music.set_volume(100)
        pygame.mixer.music.play()

    def playAttentionSound(self):
        """
            joue le son de la liste
        """
        randomSound = random.randint(0,len(self.lostHealthPointPathList)-1)
        self.playSound(self.lostHealthPointPathList[randomSound])

    def playShootSound(self):
        self.playSound(self.shootSoundPath)

    def playShieldSound(self):
        self.playSound(self.shieldSoundPath)
    
    def playGameOverSound(self):
        self.playSound(self.oussem)




